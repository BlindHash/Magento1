<?php
require_once  'TapLink/Client.php';
require_once 'TapLink/Response.php';

use \TapLink\TapLink\Client;

$appId = "7ddf60de9250dce2f9f9a4ff1f5be257eb42e81d872a9381271edddae1fb83f2f99b89f138354fb8098d1e9b6681d6b0a58bbd2b26637b545c1c32607e85d7cf";
$taplink = new Client($appId);

$salt = getRandomString();
$hash = hash_hmac(Client::$hashAlgorithm, "secret", $salt);

//Encrypting password with Blind hash
$res = $taplink->newPassword($hash);

// Confirm Password
$hash2 = hash_hmac(Client::$hashAlgorithm, "secret", $salt);

// Verify both passwords with blindhash
$res = $taplink->verifyPassword($hash2, $res->hash2Hex);
if ($res->err) {
    echo "An error occurred: " . $res->err;
    return;
}

echo sprintf("Match: %s\n", $res->matched ? "true" : "false");
echo "Version: {$res->versionId}\n";
echo "Salt2Hex: {$res->salt2Hex}\n";
echo "Hash2Hex: {$res->hash2Hex}\n";
echo "New version id: {$res->newVersionId}\n";
echo "New Salt2Hex: {$res->newSalt2Hex}\n";
echo "===================================\n";

function getRandomString($length = 64, $chars = null)
{
    $str = '';
    if (null === $chars) {
        $chars = 'abcdef0123456789';
    }

    if (function_exists('openssl_random_pseudo_bytes')) {
        // use openssl lib if it is installed
        for ($i = 0, $lc = strlen($chars) - 1; $i < $length; $i++) {
            $bytes = openssl_random_pseudo_bytes(PHP_INT_SIZE);
            $hex = bin2hex($bytes); // hex() doubles the length of the string
            $rand = abs(hexdec($hex) % $lc); // random integer from 0 to $lc
            $str .= $chars[$rand]; // random character in $chars
        }
    } elseif ($fp = @fopen('/dev/urandom', 'rb')) {
        // attempt to use /dev/urandom if it exists but openssl isn't available
        for ($i = 0, $lc = strlen($chars) - 1; $i < $length; $i++) {
            $bytes = @fread($fp, PHP_INT_SIZE);
            $hex = bin2hex($bytes); // hex() doubles the length of the string
            $rand = abs(hexdec($hex) % $lc); // random integer from 0 to $lc
            $str .= $chars[$rand]; // random character in $chars
        }
        fclose($fp);
    } else {
        // fallback to mt_rand() if all else fails
        mt_srand();
        for ($i = 0, $lc = strlen($chars) - 1; $i < $length; $i++) {
            $rand = mt_rand(0, $lc); // random integer from 0 to $lc
            $str .= $chars[$rand]; // random character in $chars
        }
    }

    return $str;
}